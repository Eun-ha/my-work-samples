    
winW = $(window).outerWidth();
winH = $(window).outerHeight();

$(document).ready(function() {
	uiLocation();
	deps();		
	selectBoxUi();

	$('.pop_search').css({
		'width':winW,
		'height':winH
		});	
	$(document).on('click', function(event){ //Document click �� ��Ӵٿ� �޴� ������
		var except = $('.dept');
		if(!$(event.target).parents().is(except)){
			$('.dept').removeClass('on');
		}
	});
});


function uiLocation(){
	$('.dept .tit').on('click', function(){
		$(this).parent().addClass('on');	
	});
}
/*gnb deps ��ũ��Ʈ*/
function deps(){
	var deps_01 = $('.wrap_deps .depth_01 .tit');	
	deps_01.on('click',function(e){			
		e.preventDefault();
		if(!$(this).parent().hasClass('on')){
			$(this).parent().addClass('on');
			$(this).next('.depth_02').show();
			$(this).parent('li').siblings('li').removeClass('on').children('.tit').removeClass('on').next('.depth_02').hide();
			$(this).parent('li').addClass('on');					
			
		}else{
			$(this).parent().removeClass('on');
			$(this).next('.depth_02').hide();
			$(this).parent('li').removeClass('on');					
		}				
	});
}  

/* select Ui */
function selectBoxUi (){        
	var selectTarget = $('.selectbox select');			
	$(selectTarget).each(function(i){
		if($(this).attr('disabled')){
			$(this).parent().addClass('disabled')
		}
	})
	selectTarget.change(function(){
		var select_name = $(this).children('option:selected').text();
		$(this).siblings('label').text(select_name);
	});
}


 
    